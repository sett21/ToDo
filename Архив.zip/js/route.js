var MegaTodo = angular.module('MegaTodo', ['ngRoute']);

